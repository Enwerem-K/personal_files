# Modelling can do three things in spatial data
# 1. Modelling the influence of one site on another as spatial areas are somewhat influenced by each other
# 2. Using areas where abundance of data is collected to smoothen areas where there is paucity of data
# 3. Using areas with data to predict outcomes in areas where no data was collected.


library(sp)
library(spdep)
library(tmap)
library(tidyverse)
library(readxl)
library(RColorBrewer)
library(haven)
library(leaflet)
library(sf)
library(terra)
library(rio)
library(INLA)

#nig <- st_read("sdr_subnational_boundaries2.shp")
nig <- st_read("C:/Users/Ezra Gayawan/Documents/DHS Data/GPS data/Nig2008/shps/sdr_subnational_boundaries2.shp")
 ### Plotting Nigeria map

plot(st_geometry(nig))

nig$ID <- 1:37

lagkn <- nig[c(36,10),]

ss <- nig[1:10,]
s27 <- nig[c(6,36),]

plot(st_geometry(s27))

plot(st_geometry(nig))
tm_shape(nig)+ tm_borders(col = "red")
ggplot(lagkn)+ geom_sf(fill=NA) +theme_bw()

#ccc <- read_excel("C:/Users/Ezra Gayawan/Documents/DHS Data/GPS data/Spatial covariates NDHS2018/NGGE7BFL/NGGE7BFL.xlsx")
points <- st_as_sf(ccc, coords = c("LONGNUM","LATNUM"), crs = 4326)

############## Plotting points on map
windows(record = T)
plot(st_geometry(nig))

plot(st_geometry(points), pch=20,  col="red", add=T)

##############

#bw <- read.csv("C:/Users/Ezra Gayawan/Documents/Students_works/Undergraduate/Ayodele/prop.csv")
names(nig)
bw <- rename(bw, REGCODE=ID)
bw$REGCODE <- bw$REGCODE*10
bw1 <- inner_join(nig, bw)

tm_shape(bw1)+ tm_bubbles("Proportion", col="red")+ tm_borders()+tm_legend("TT")

  


#####
tm_shape(bw1) + tm_fill(col="Proportion") + tm_polygons(style="cont")

tm_shape(bw1) + tm_polygons("Proportion", style="quantile")+
  #tm_legend(position=c("left", "bottom"), title="ABC")
  tm_layout(legend.outside = F,
            legend.stack = "vertical",
            legend.outside.position = "bottom",
            legend.outside.size = 0.1, 
            legend.text.size = 1.5,
            legend.title.size=1.5
  )
  

  

######
colours <- colorNumeric(palette = "Oranges", domain = bw1$Proportion,
                        reverse=FALSE)
leaflet(data=bw1) %>%
  addTiles() %>%
  addPolygons(fillColor = ~colours(Proportion),
              color="", weight=1,
              fillOpacity = 0.6) %>%
  addLegend(pal = colours, values = bw1$Proportion,
            opacity = 1, title="Prevalence") %>%
  addScaleBar(position="bottomleft")
   
###########################
nig0 <- st_read("C:/Users/Ezra Gayawan/Documents/DHS Data/GPS data/Boundary file WA/Nigeria/gadm36_NGA_0.shp")
nig1 <- st_read("C:/Users/Ezra Gayawan/Documents/DHS Data/GPS data/Boundary file WA/Nigeria/gadm36_NGA_1.shp")
nig2 <- st_read("C:/Users/Ezra Gayawan/Documents/DHS Data/GPS data/Boundary file WA/Nigeria/gadm36_NGA_2.shp")

plot(st_geometry(nig0), lwd=4)
plot(st_geometry(nig1), lwd=2, add=T)
plot(st_geometry(nig2), lwd=0.5, add=T)


a1 <- tm_shape(nig0)+ tm_borders(lwd = 5)
a2 <- tm_shape(nig1)+ tm_borders(lwd = 3)
a3 <- tm_shape(nig2)+ tm_borders(lwd = 0.6)

a1+a2+a3
View(nig2)

fct <- nig2[c(277:282),]
plot(st_geometry(fct))

d <- read_stata("C:/Users/Ezra Gayawan/Documents/Workshops/AMMnet_FUTA/HandsOnTrainigGeospat/NG_2021_MIS/NGPR81DT/NGPR81FL.dta")
names(d)
View(d)
str(d)

d1 = select(d,"hv001","hv009","hv014","hv025", "hv024",
            "hv040","hml35","hv204","hv216",
            "hv220","hv227","hv228","hv270","hv104","hv105",
            "hc57", "hc53")
View(d1)

d2 = rename(d1, cluster = hv001,
            NoOfHouseHoldMember = hv009,
            NoOfChildren = hv014,
            state = hv024,
            residence = hv025,
            malaria = hml35,
            noOfRooms=hv216,
            ageOfHouseholdHead = hv220,
            MosquitoNet = hv227,
            NoOfChildSplepUnderMN = hv228,
            WealthIndex = hv270,
            Gender = hv104,
            Age = hv105,
            anemia=hc57,hemoglobin=hc53)

d3 <- na.omit(d2) 
View(d3)
# Delete irregular entries. Use str(dataset3) to see these indicators of irregularity
str(d3)
d3 = d3[rowSums(d3==99|d3==999|
                  d3==996|d3==998|
                  d3==98)==0,]

table(d3$anemia)
table(d3$malaria)

# Calculate prevalence of malaria by state

malariapreval <- d3 %>% group_by(state) %>% 
  summarise(prevalence = sum(malaria)/n())



nig <- st_read("C:/Users/Ezra Gayawan/Documents/Workshops/DRASA/shps/sdr_subnational_boundaries2.shp")
plot(st_geometry(nig))
### To have a common name with which to combine the data and shapefile
malariapreval <- rename(malariapreval, REGCODE=state)
#malariapreval$REGCODE <- malariapreval$REGCODE*10

nig_mal <- inner_join(nig, malariapreval)
### Another way of merging the data and shapfile
nig_mal <- merge(nig, malariapreval, by="REGCODE")

 ggplot(nig_mal) + geom_sf(aes(fill=prevalence))+
  scale_fill_gradientn(colors=brewer.pal(n=9, name="YlOrRd"))+
  labs(title = "Malaria Prevalence")+theme_bw()


### Creating interactive visualization with leaflet
library(leaflet)
colours <- colorNumeric(palette = "YlOrRd", domain = nig_mal$prevalence,
                        reverse=FALSE)
leaflet(data=nig_mal) %>%
  addTiles() %>%
  addPolygons(fillColor = ~colours(prevalence),
              color="", weight=1,
              fillOpacity = 0.6) %>%
  addLegend(pal = colours, values = nig_mal$prevalence,
            opacity = 1, title="Prevalence") %>%
  addScaleBar(position="bottomleft")


#### Creating a neighbourhood or adjacency matrix: An important concept in 
### Modeling spatial dependency (autocorrelation)

W.nb <- poly2nb(nig)
W <- nb2mat(W.nb, style = "B")
class(W)
dim(W)
W[1:5, 1:5]

W.list <- nb2listw(W.nb, style = "B")
moran.mc(x = nig_mal$prevalence, listw = W.list, nsim = 100000)

## The result shows evidence of spatial clustering

#### Computing LISA
q <- localG(x = nig_mal$prevalence, listw = W.list)

qq <- read.csv("C:/Users/Ezra Gayawan/Documents/Personal/MMF/geospatial/lisa.csv")
qq$REGCODE <- qq$REGCODE*10
nig_qq <- inner_join(nig,qq)

tm_shape(nig_qq) + tm_polygons("class")

################## INLA
#############################################
############
library(INLA)
nig <- st_read(here("geospatial modelling", "geo_files", "shps",  "sdr_subnational_boundaries2.shp"))

demo <- import(here("geospatial modelling", "geo_files", "NGPR81FL.DTA"))

d1 = dplyr::select(demo,"hv001","hv009","hv014","hv025", "hv024",
            "hv040","hml35","hv204","hv216",
            "hv220","hv227","hv228","hv270","hv104","hv105",
            "hc57", "hc53")
View(d1)

d2 = rename(d1, cluster = hv001,
            NoOfHouseHoldMember = hv009,
            NoOfChildren = hv014,
            state = hv024,
            residence = hv025,
            malaria = hml35,
            noOfRooms=hv216,
            ageOfHouseholdHead = hv220,
            MosquitoNet = hv227,
            NoOfChildSplepUnderMN = hv228,
            WealthIndex = hv270,
            Gender = hv104,
            Age = hv105,
            anemia=hc57,hemoglobin=hc53)

d3 <- na.omit(d2) 

w <- poly2nb(nig)

nb2INLA("nw.graph", w)

nw.adj <- inla.read.graph("nw.graph")

View(nw.adj)
image(inla.graph2matrix(nw.adj),xlab="",ylab="")

formula1 <- malaria ~  factor(Gender) + factor(WealthIndex) + 
  factor(residence) +
  f(state, model = "besag", graph = nw.adj)+
  f(ageOfHouseholdHead, model = "rw1")

formula2 <- malaria ~ f(state,MosquitoNet, model = "besag", graph = nw.adj)+
  f(ageOfHouseholdHead, model = "rw1") + factor(Gender)


mod1 <- inla(formula1, family = "binomial", data = d3,
             control.compute = list(dic=T, waic=T))

summary(mod1)
plot(mod1)
sp <- mod1$summary.random$state
View(sp)
View(nig)
sp <- rename(sp, REGCODE=ID)
sp <- sp %>% mutate(REGCODE = REGCODE*10)
sp2 <- inner_join(nig, sp)

ggplot(sp2)+geom_sf(aes(fill=mean))

ggplot(sp2) + geom_sf(aes(fill=exp(mean)))+
  scale_fill_gradientn(colors=brewer.pal(n=9, name="YlOrRd"))+
  labs(title = "Malaria Prevalence")+theme_bw()

tm_shape(sp2) + tm_polygons(col = "mean", palette = "YlOrRd", style = "cont")

# Convert the mean (which has negatives) to Odds Ratio by doing the exponential
sp3 <- sp2 %>% mutate(OR = exp(mean))
tm_shape(sp3) + tm_polygons(col = "OR", palette = "YlOrRd", style = "cont")

# modelling prevalence
prev <- mod1$summary.fitted.values
View(prev) # this gives the fitted probability values (mean) of having malaria for each person in the data

# Now we summarize the mean values for each state to fine the prevalence for each state
# First join the prevalence data with the d3 data
prev_new <- cbind(d3, prev) 

# Then group by state
prev_new2 <- prev_new %>% 
  group_by(state) %>% 
  summarize(prevalence = mean(mean))

# Rename the state variable in the dataset to REGCODE
prev_new2 <- prev_new2 %>% rename(REGCODE = state)
# make the values in the new REGCODE variable to be multiples of 10 similar to that in the shape file "nig"
prev_new4 <- prev_new2 %>% mutate(REGCODE = REGCODE*10)
# Join the two data sets
prev_new5 <- inner_join(nig, prev_new4)
# Plot the map using tm_shape
tm_shape(prev_new5) + tm_polygons(col = "prevalence", 
                                  palette = "YlOrRd", 
                                  style = "cont") +
  tm_text("DHSREGEN")

# Juxtapose the two maps using tmap_arrange function
tmap_arrange(tm_shape(sp3) + tm_polygons(col = "OR", palette = "YlOrRd", style = "cont"),
             tm_shape(prev_new5) + tm_polygons(col = "prevalence", 
                                               palette = "YlOrRd", 
                                               style = "cont"))

# Working on the age of Household head variable
age <- mod1$summary.random$ageOfHouseholdHead
ggplot(age)+geom_line(aes(ID, mean))+ geom_line(aes(ID, `0.025quant`))+
  geom_line(aes(ID, `0.975quant`))+theme_bw()+ 
  xlab("Age of household head")+ylab("Estimates")

# Modelling age
d3$state1 <- d3$state

formula3 <- malaria ~ factor(Gender)+
  factor(WealthIndex)+
  factor(residence)+
  f(ageOfHouseholdHead, model = "rw1")+
  f(state1, MosquitoNet, model = "besag", graph = nw.adj)

mod3 <- inla(formula3,
             family = "binomial",
             data = d3,
             control.compute = list(dic = T, waic = T))

mois <- mod3$summary.random$state1
spa <- rename(mois, REGCODE = ID)
spa <- spa %>% mutate(REGCODE = REGCODE*10)
nigsp <- inner_join(nig, spa)
nigsp$odds <- exp(nigsp$mean) 
estimate <- tm_shape(nigsp)+
  tm_polygons(col = "mean",
              palette = "YlOrRd",
              style = "cont")

odds <- tm_shape(nigsp)+
  tm_polygons(col = "odds",
              palette = "YlOrRd",
              style = "cont")

tmap_arrange(estimate, odds)

### Plotting estimated prevalence


spp <- mod1$summary.fitted.values
View(spp)
spp <- data.frame(d3,spp)

spp <- spp %>% group_by(state) %>% 
  summarise(prev=mean(mean))

formula <- anemia1~f(region,model = "bym",graph = nw.adj)

formula2 <- malaria ~ factor(WealthIndex) +factor(Gender) + 
  f(ageOfHouseholdHead, model = "rw2") +
  f(state, model = "besag", graph = nw.adj)
 

model2 <- inla(formula2,data=d3,family = "binomial",
               control.compute = list(dic=T, waic=T))

  age <- model2$summary.random$ageOfHouseholdHead
View(age)  

ggplot(age)+geom_line(aes(ID, mean)) +geom_line(aes(ID, `0.025quant`))+
  geom_line(aes(ID, `0.975quant`)) + theme_bw() + xlab("Age of household head")+
  ylab("Estimates")
