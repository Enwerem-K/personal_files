library(sp)
library(spdep)
library(tmap)
library(tidyverse)
library(readxl)
library(RColorBrewer)
library(haven)

nig <- st_read("C:/Users/Ezra Gayawan/Documents/DHS Data/GPS data/Nig2008/shps/sdr_subnational_boundaries2.shp")
### Plotting Nigeria map
plot(st_geometry(nig))
tm_shape(nig)+ tm_borders()
ggplot(nig)+ geom_sf()

ccc <- read_excel("C:/Users/Ezra Gayawan/Documents/DHS Data/GPS data/Spatial covariates NDHS2018/NGGE7BFL/NGGE7BFL.xlsx")
points <- st_as_sf(ccc, coords = c("LONGNUM","LATNUM"), crs = 4326)

############## Plotting points on map
windows(record = T)
plot(st_geometry(nig))
plot(st_geometry(points), pch=20, add=T, col="red")

##############

bw <- read.csv("C:/Users/Ezra Gayawan/Documents/Students_works/Undergraduate/Ayodele/prop.csv")
names(nig)
bw <- rename(bw, REGCODE=ID)
bw$REGCODE <- bw$REGCODE*10
bw1 <- inner_join(nig, bw)

tm_shape(bw1)+ tm_bubbles("Proportion", col="red")+ tm_borders()


#####
tm_shape(bw1) + tm_fill(col="Proportion")
tm_shape(bw1) + tm_polygons("Proportion")

###########################


d <- read_stata("C:/Users/Ezra Gayawan/Documents/Workshops/AMMnet_FUTA/HandsOnTrainigGeospat/NG_2021_MIS/NGPR81DT/NGPR81FL.dta")
names(d)
View(d)
str(d)

d1 = select(d,"hv001","hv009","hv014","hv025", "hv024",
            "hv040","hml35","hv204","hv216",
            "hv220","hv227","hv228","hv270","hv104","hv105",
            "hc57", "hc53")
View(d1)

d2 = rename(d1, cluster = hv001,
            NoOfHouseHoldMember = hv009,
            NoOfChildren = hv014,
            state = hv024,
            residence = hv025,
            malaria = hml35,
            noOfRooms=hv216,
            ageOfHouseholdHead = hv220,
            MosquitoNet = hv227,
            NoOfChildSplepUnderMN = hv228,
            WealthIndex = hv270,
            Gender = hv104,
            Age = hv105,
            anemia=hc57,hemoglobin=hc53)

d3 <- na.omit(d2) 

# Delete irregular entries. Use str(dataset3) to see these indicators of irregularity
str(d3)
d3 = d3[rowSums(d3==99|d3==999|
                  d3==996|d3==998|
                  d3==98)==0,]

table(d3$anemia)
table(d3$malaria)

# Calculate prevalence of malaria by state

malariapreval <- d3 %>% group_by(state) %>% 
  summarise(prevalence = sum(malaria)/n())

nig <- st_read("C:/Users/Ezra Gayawan/Documents/Workshops/DRASA/shps/sdr_subnational_boundaries2.shp")

### To have a common name with which to combine the data and shapefile
malariapreval <- rename(malariapreval, REGCODE=state)
malariapreval$REGCODE <- malariapreval$REGCODE*10

nig_mal <- inner_join(nig, malariapreval)
### Another way of merging the data and shapfile
nig_mal <- merge(nig, malariapreval, by="REGCODE")

 ggplot(nig_mal) + geom_sf(aes(fill=prevalence))+
  scale_fill_gradientn(colors=brewer.pal(n=9, name="YlOrRd"))+
  labs(title = "Malaria Prevalence")+theme_bw()


### Creating interactive visualization with leaflet
library(leaflet)
colours <- colorNumeric(palette = "YlOrRd", domain = nig_mal$prevalence,
                        reverse=FALSE)
leaflet(data=nig_mal) %>%
  addTiles() %>%
  addPolygons(fillColor = ~colours(prevalence),
              color="", weight=1,
              fillOpacity = 0.6) %>%
  addLegend(pal = colours, values = nig_mal$prevalence,
            opacity = 1, title="Prevalence") %>%
  addScaleBar(position="bottomleft")


#### Creating a neighbourhood or adjacency matrix: An important concept in 
### Modeling spatial dependency (autocorrelation)

W.nb <- poly2nb(nig)
W <- nb2mat(W.nb, style = "B")
class(W)
dim(W)
W[1:5, 1:5]

W.list <- nb2listw(W.nb, style = "B")
moran.mc(x = nig_mal$prevalence, listw = W.list, nsim = 10000)

## The result shows evidence of spatial clustering

#### Computing LISA
localG(x = nig_mal$prevalence, listw = W.list)


# Modelling in geospatial -------------------------------------------------


