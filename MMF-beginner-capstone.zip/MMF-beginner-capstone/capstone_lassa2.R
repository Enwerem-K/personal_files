
# Title -------------------------------------------------------------------

# Name: Nigeria Malaria Modelling Fellowship Capstone Project
# Organization: Corona Management systems
# Topic: Mathematical modelling to forecast the optimization of Rapid Point-of-Care Diagnostic Tests for Lassa Fever
# Author: Kenneth Enwerem
# Affiliation: International Research Center of Excellence, Institute of Human Virology Nigeria
# Mentor: Dr Nwadiuto Ojeilo
# Date: August 2024



# Load the necessary library ----------------------------------------------

pacman::p_load(deSolve, 
               rio, 
               janitor, 
               gtsummary, 
               tidyverse)


# Solve the differential equation and plot the graph ----------------------


# 1. Define the SIR Model function
sir_model <- function(time, state, parameters) {
  with(as.list(c(state, parameters)), {
    # Lassa fever prevalence
    #pos_rate = (prevalence * gamma + (1 - prevalence) * (1 - alpha))
    #neg_rate = (prevalence * (1 - gamma) + (1 - prevalence) * alpha)
    
    # Rate of new infections (1)
    dSh <- lambda_h - beta_h*S_h*I_h/N_h - beta_v*S_h*I_v/N_h - mu_h*S_h + theta*R_h + gamma*H_h
    
    # Rate of infection  (2)
    dFh <- beta_h*S_h*I_h/N_h + beta_v*S_h*I_v/N_h - (mu_h*F_h + alpha*F_h + (1 - alpha)*F_h)
    
    # Rate of POCT positivity (3)
    dPt <- alpha*F_h - (mu_h*P_t + sigma*P_t + (1 - sigma)*P_t)
    
    # Rate of POCT negativity (4)
    dNt <- (1 - alpha)*F_h - (mu_h*N_t + omega*N_t + (1 - omega)*N_t)
    
    # Rate of change from infectious to recovered (5)
    dIh <- sigma*P_t + (1 - omega)*N_t - (mu_h + delta_h + epsilon_h)*I_h
    
    # Rate of transition from POCT negativity to susceptible  (6)
    dHh <- omega*N_t + (1 - sigma)*P_t - (mu_h + gamma)*H_h
    
    # Rate of recovery  (7)
    dRh <- epsilon_h*H_h - (mu_h + theta)*R_h
    
    # Rate of new infections in vector  (8)
    dSv <- lambda_v - beta_v*S_v*I_v/N_h - mu_v*S_v
    
    # Rate of change from infectiousness in vector (9)
    dIv <- beta_v*S_v*I_v/N_h - mu_v*I_v   
    
    # Return the rates of change
    list(c(dSh, dHh, dPt, dNt, dIh, dHh, dRh, dSv, dIv))
    
  })
}

# Initial state values (S = Susceptible, I = Infectious, R = Recovered)
init_state <- c(S_h = 4461137,    # Susceptible human population
                F_h = 3482,       # Exposed human population
                P_t = 348,        # Population who tested RDT positive
                N_t = 3134,        # Population who tested RDT negative
                I_h = 300,        # Population who became infectious after either positive or negative
                H_h = 3182,        # Population who did not develop disease after testing either positive or negative 
                R_h = 0,         # Population who recovered from the infection
                S_v = 55330000,   # Population of susceptible vectors
                I_v = 2766500)    # Population of infectious vectors

# Parameters (beta = infection rate, gamma = recovry rate, N = total population)
parameters <- c(lambda_h = 2500,   # recruitment rate in humans
                lambda_v = 0.05,   # recruitment rate in vectors
                beta_h = 0.22,     # rate of infection transmission (human to human)
                beta_v = 0.075,    # rate of infection transmission (vector to human)
                mu_h = 0.00005,    # natural death rate for humans
                mu_v = 0.002,      # natural death rate for vectors
                delta_h = 0.21,    # death rate due to infection in humans
                alpha = 0.462,     # positivity rate
                sigma = 0.774,     # true positivity rate
                omega = 0.849,     # true negativity rate
                epsilon_h = 0.0517,# recovery rate in humans
                theta = 0.0067,  # rate of recruitment from recovered to susceptible population
                gamma = 0.0067,  # rate of recruitment from non-infected to susceptible population
                N_h = 4464619)     # total population

# Time over which to simulate
time <- seq(from = 0,    # from 0 up to 35 at intervals of 1
            to = 20, 
            by = 1)

# Solve the model using ode function from deSolve package
output <- ode(y = init_state,      # inital state variables
              times = time,        # times sequence
              func = sir_model,    # sir_model function as above
              parms = parameters)  # stipulate parameters as above

# Convert output to a dat frame for easier handling
output_df <- as.data.frame(output)

# Export data to Excel
export(output_df, "simulation_data_lassa.xlsx")



# Data visualization -------------------------------------------------------
# Solve the differential equation and plot the graph ----------------------


# 1. Define the SIR Model function
sir_model <- function(time, state, parameters) {
  with(as.list(c(state, parameters)), {
    # Lassa fever prevalence
    #pos_rate = (prevalence * gamma + (1 - prevalence) * (1 - alpha))
    #neg_rate = (prevalence * (1 - gamma) + (1 - prevalence) * alpha)
    
    # Rate of new infections (1)
    dSh <- lambda_h - beta_h*S_h*I_h/N_h - beta_v*S_h*I_v/N_h - mu_h*S_h + theta*R_h + gamma*H_h
    
    # Rate of infection  (2)
    dFh <- beta_h*S_h*I_h/N_h + beta_v*S_h*I_v/N_h - (mu_h*F_h + alpha*F_h + (1 - alpha)*F_h)
    
    # Rate of POCT positivity (3)
    dPt <- alpha*F_h - (mu_h*P_t + sigma*P_t + (1 - sigma)*P_t)
    
    # Rate of POCT negativity (4)
    dNt <- (1 - alpha)*F_h - (mu_h*N_t + omega*N_t + (1 - omega)*N_t)
    
    # Rate of change from infectious to recovered (5)
    dIh <- sigma*P_t + (1 - omega)*N_t - (mu_h + delta_h + epsilon_h)*I_h
    
    # Rate of transition from POCT negativity to susceptible  (6)
    dHh <- omega*N_t + (1 - sigma)*P_t - (mu_h + gamma)*H_h
    
    # Rate of recovery  (7)
    dRh <- epsilon_h*H_h - (mu_h + theta)*R_h
    
    # Rate of new infections in vector  (8)
    dSv <- lambda_v - beta_v*S_v*I_v/N_h - mu_v*S_v
    
    # Rate of change from infectiousness in vector (9)
    dIv <- beta_v*S_v*I_v/N_h - mu_v*I_v   
    
    # Return the rates of change
    list(c(dSh, dHh, dPt, dNt, dIh, dHh, dRh, dSv, dIv))
    
  })
}

# Initial state values (S = Susceptible, I = Infectious, R = Recovered)
init_state <- c(S_h = 4461137,    # Susceptible human population
                F_h = 3482,       # Exposed human population
                P_t = 348,        # Population who tested RDT positive
                N_t = 3134,        # Population who tested RDT negative
                I_h = 300,        # Population who became infectious after either positive or negative
                H_h = 3182,        # Population who did not develop disease after testing either positive or negative 
                R_h = 0,         # Population who recovered from the infection
                S_v = 55330000,   # Population of susceptible vectors
                I_v = 2766500)    # Population of infectious vectors

# Parameters (beta = infection rate, gamma = recovry rate, N = total population)
parameters <- c(lambda_h = 2500,   # recruitment rate in humans
                lambda_v = 0.05,   # recruitment rate in vectors
                beta_h = 0.22,     # rate of infection transmission (human to human)
                beta_v = 0.075,    # rate of infection transmission (vector to human)
                mu_h = 0.00005,    # natural death rate for humans
                mu_v = 0.002,      # natural death rate for vectors
                delta_h = 0.21,    # death rate due to infection in humans
                alpha = 0.462,     # positivity rate
                sigma = 0.974,     # true positivity rate
                omega = 0.849,     # true negativity rate
                epsilon_h = 0.0517,# recovery rate in humans
                theta = 0.0067,  # rate of recruitment from recovered to susceptible population
                gamma = 0.0067,  # rate of recruitment from non-infected to susceptible population
                N_h = 4464619)     # total population

# Time over which to simulate
time <- seq(from = 0,    # from 0 up to 35 at intervals of 1
            to = 20, 
            by = 1)

# Solve the model using ode function from deSolve package 

# output 0: baseline true positivity rate (sigma_0 = 0.0.774)
output_0 <- ode(y = init_state,      # inital state variables
                times = time,        # times sequence
                func = sir_model,    # sir_model function as above
                parms = parameters)  # stipulate parameters as above

# Convert output to a dat frame for easier handling
output_0 <- as.data.frame(output_0)

# output 1: true-positivity-rate_1 (sigma_1 = 0.874) 
output_1 <- ode(y = init_state,      # inital state variables
                times = time,        # times sequence
                func = sir_model,    # sir_model function as above
                parms = parameters)  # stipulate parameters as above

# Convert output to a dat frame for easier handling
output_1 <- as.data.frame(output_1)


# output 2: true-positivity-rate_2 (sigma_2 = 0.974) 
output_2 <- ode(y = init_state,      # inital state variables
                times = time,        # times sequence
                func = sir_model,    # sir_model function as above
                parms = parameters)  # stipulate parameters as above
# Convert output to a dat frame for easier handling
output_2 <- as.data.frame(output_2)

# Export data to Excel
#export(output_df, "simulation_data_lassa_negativity_rates.xlsx")

# variations of diagnostic parameters at different positive predictive values
positivity_rates <- data.frame(output_0$P_t, output_0$N_t, output_0$I_h, output_0$H_h,
                               output_1$P_t, output_1$N_t, output_1$I_h, output_1$H_h,
                               output_2$P_t, output_2$N_t, output_2$I_h, output_2$H_h,
                               output_2$time)
positivity_rates_df <- export(positivity_rates, "positivity_rates.xlsx") 

# variations of diagnostic parameters at different negative predictive values
negativity_rates <- data.frame(output_0$P_t, output_0$N_t, output_0$I_h, output_0$H_h,
                               output_1$P_t, output_1$N_t, output_1$I_h, output_1$H_h,
                               output_2$P_t, output_2$N_t, output_2$I_h, output_2$H_h,
                               output_2$time)
negativity_rates_df <- export(negativity_rates, "negativity_rates.xlsx")

# difference in mean values of RDT positives and True positives compartments
change_0 <- mean(output_0$I_h - output_0$P_t) # when positivity rate is 0.774 
change_1 <- mean(output_1$I_h - output_1$P_t) # when positivity rate is 0.874
change_2 <- mean(output_2$I_h - output_2$P_t) # when positivity rate is 0.974

# percentage change in increase of difference between RDT positives and True positives
percent_change_0_1 <-  ((change_0 - change_1)/change_0)*100 # between positivity rates of 0.774 and 0.874
percent_change_0_2 <-  ((change_0 - change_2)/change_0)*100 # between positivity rates of 0.774 and 0.974
percent_change_0_1
percent_change_0_2

# t-test of significance
positivity_rates %>% 
  t.test(output_0$I_h ~ output_1$I_h, 
         data = .,
         paired = T,
         conf.level = 0.95)

pos_rates2 <- positivity_rates %>% drop_na() 
t.test(pos_rates2$output_0.I_h,
       pos_rates2$output_1.I_h,
       paired = T)

negativity_rates

export(negativity_rates, "neg_rates.xlsx")
# Data visualization -------------------------------------------------------
# Plot the results
# 1. Comparison of model compartments
output_df %>% 
  ggplot(aes(x = time))+
  geom_line(aes(y = S_h, color = "Susceptible"), size = 1.2)+
  geom_line(aes(y = F_h, color = "Symptomatic"), size = 1.2)+
  geom_line(aes(y = P_t, color = "RDT positives"), size = 1.2)+
  geom_line(aes(y = I_h, color = "True positives"), size = 1.2)+
  geom_line(aes(y = N_t, color = "RDT negatives"), size = 1.2)+
  geom_line(aes(y = H_h, color = "True negatives"), size = 1.2)+
  geom_line(aes(y = R_h, color = "Recovered"), size = 1.2)+
  labs(x = "Time",
       y = "Population"
       #title = "Comparison of model compartments"
  )+
  scale_color_manual(
    name = "Population", 
    values = c("Susceptible" = "red",
               "Symptomatic" = "orange",
               "RDT positives" = "yellow", 
               "True positives" = "green",
               "RDT negatives" = "blue",
               "True negatives" = "pink",
               "Recovered" = "purple"))+
  #theme_classic()+
  theme(legend.position = c(0.2, 0.8))


# 2. Scenario analysis

# 2a. RDT positives vs True positives at true positivity rate of 0.774
output_df %>% 
  ggplot(aes(x = time))+
  geom_line(aes(y = output_0$P_t, color = "RDT Positives"), size = 1.2)+
  geom_line(aes(y = output_0$I_h, color = "True Positives"), size = 1.2, 
            linetype = "dashed")+
  labs(x = "Time",
       y = "Population"
       #title = "RDT Posivites vs True positives at positivity rate = 0.774"
  )+
  scale_color_manual(
    name = "Population", 
    values = c("RDT Positives" = "red",
               "True Positives" = "blue"))+
  #theme_classic()+
  theme(legend.position = c(0.2, 0.8))

# 2b. RDT positives vs True positives at true positivity rate of 0.874
output_df %>% 
  ggplot(aes(x = time))+
  geom_line(aes(y = output_1$P_t, color = "RDT Positives"), size = 1.2)+
  geom_line(aes(y = output_1$I_h, color = "True Positives"), size = 1.2, 
            linetype = "dashed")+
  labs(x = "Time",
       y = "Population"
       #title = "RDT Posivites vs True positives at positivity rate = 0.874"
  )+
  scale_color_manual(
    name = "Population", 
    values = c("RDT Positives" = "red",
               "True Positives" = "blue"))+
  #theme_classic()+
  theme(legend.position = c(0.2, 0.8))


# 2c. RDT positives vs True positives at true positivity rate of 0.974
output_df %>% 
  ggplot(aes(x = time))+
  geom_line(aes(y = output_2$P_t, color = "RDT Positives"), size = 1.2)+
  geom_line(aes(y = output_2$I_h, color = "True Positives"), size = 1.2, 
            linetype = "dashed")+
  labs(x = "Time",
       y = "Population"
       #title = "RDT Posivites vs True positives at positivity rate = 0.974"
  )+
  scale_color_manual(
    name = "Population", 
    values = c("RDT Positives" = "red",
               "True Positives" = "blue"))+
  #theme_classic()+
  theme(legend.position = c(0.2, 0.8))


# 3a. RDT negatives vs True negatives at true negativity rate of 0.85
negativity_rates %>% 
  ggplot(aes(x = time))+
  geom_line(aes(y = output_0$N_t, color = "RDT Negatives"), size = 1.2)+
  geom_line(aes(y = output_0$H_h, color = "True Negatives"), size = 1.2, 
            linetype = "dashed")+
  labs(x = "Time",
       y = "Population",
       title = "RDT Negatives vs True Negatives at negativity rate = 0.85"
  )+
  scale_color_manual(
    name = "Population", 
    values = c("RDT Negatives" = "red",
               "True Negatives" = "blue"))+
  #theme_classic()+
  theme(legend.position = c(0.2, 0.8))

# 3b. RDT positives vs True positives at true positivity rate of 0.93
negativity_rates %>% 
  ggplot(aes(x = time))+
  geom_line(aes(y = output_1$N_t, color = "RDT Negatives"), size = 1.2)+
  geom_line(aes(y = output_1$H_h, color = "True Negatives"), size = 1.2, 
            linetype = "dashed")+
  labs(x = "Time",
       y = "Population",
       title = "RDT Negatives vs True Negatives at negativity rate = 0.93"
  )+
  scale_color_manual(
    name = "Population", 
    values = c("RDT Negatives" = "red",
               "True Negatives" = "blue"))+
  #theme_classic()+
  theme(legend.position = c(0.2, 0.8))


# 3c. RDT positives vs True positives at true positivity rate of 0.99
negativity_rates %>% 
  ggplot(aes(x = time))+
  geom_line(aes(y = output_2$N_t, color = "RDT Negatives"), size = 1.2)+
  geom_line(aes(y = output_2$H_h, color = "True Negatives"), size = 1.2, 
            linetype = "dashed")+
  labs(x = "Time",
       y = "Population",
       title = "RDT Negatives vs True Negatives at negativity rate = 0.99"
  )+
  scale_color_manual(
    name = "Population", 
    values = c("RDT Negatives" = "red",
               "True Negatives" = "blue"))+
  #theme_classic()+
  theme(legend.position = c(0.2, 0.8))


# Notes -------------------------------------------------------------------

# Define the positivity and negativity rates as they relate to sensitivity and specificity
# Lassa fever prevalence


# Positivity_Rate = P×Sensitivity+(1−P)×(1−Specificity)
#pos_rate = prevalence * gamma + (1 - prevalence) * (1 - alpha)

# Negativity_rate = = P×(1−Sensitivity)+(1−P)×Specificity
#neg_rate = prevalence * (1 - gamma) + (1 - prevalence) * alpha

# which is equivalent to 1 - pos_rate


output_d <- data.frame(
  time = 1:10,
  N_t = c(10, 20, 30, 25, 15, 10, 5, 30, 25, 20),
  H_h = c(5, 10, 20, 15, 25, 30, 20, 10, 15, 5)
)

# Plot with legend
ggplot(output_d, aes(x = time)) +
  geom_line(aes(y = N_t, color = "RDT negatives")) +
  geom_line(aes(y = H_h, color = "True negatives")) +
  labs(
    x = "Time",
    y = "Population",
    title = "Comparison of RDT negatives and True negatives"
  ) +
  scale_color_manual(
    name = "Legend", 
    values = c("RDT negatives" = "blue", "True negatives" = "red")
  )
